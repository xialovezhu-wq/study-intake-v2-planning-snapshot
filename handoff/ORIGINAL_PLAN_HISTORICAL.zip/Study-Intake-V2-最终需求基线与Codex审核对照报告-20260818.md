# Study Intake Multi-Agent V2：最终需求基线与 Codex 完工审核对照报告

- **用途**：交给一个全新的 ChatGPT 项目/会话，作为不受旧对话上下文污染的“最终需求基线”。
- **使用方式**：先上传本文件；Codex 完成当前任务后，再上传 Codex 的最终报告、验收文件和审核包，由新项目逐项对照审核。
- **重要声明**：本文件记录的是用户最终确认的需求、边界和验收标准，**不证明 Codex 已经完成这些工作**。
- **整理日期**：2026-08-18（Asia/Shanghai）
- **项目**：数学、计算机 408、英语三科学习快速入库与后台预处理系统

---

# 0. 给新项目的直接开场提示词

将本报告上传到新项目后，可以直接发送下面这段话：

```text
请完整阅读《Study Intake Multi-Agent V2：最终需求基线与 Codex 完工审核对照报告》。这份文件只代表我的最终需求，不代表 Codex 已经实现。

当前先不要修改项目，也不要运行任何真实 Capture、Terra、Luna、Monitor、Promotion 或正式写入。等我上传 Codex 的最终报告、交付文件和审核包后，请把“需求基线”“Codex 自述”“实际证据”严格分开，逐项审核。

审核时必须给出：
1. 总体结论；
2. 已完成、部分完成、未完成、违规、证据不足的项目；
3. 数学、408、英语三科 Skill 是否真正对齐；
4. 三科真实只读 MCP 是否经过“发现错误—修复—重试—部署后复验”的闭环；
5. 验收控制台前端和后端是否都完成且用户可见；
6. issuer、campaign、promotion gate 是否只完成代码和 fixture 验证，没有真实执行；
7. 是否违反零 Terra、零 Luna、零真实 Capture、零 Promotion、零正式写入边界；
8. 是否真的已经达到“所有非 Live 工程完成，只剩未来真实模型 Capture 验收”；
9. 若未达到，给出最小修复清单。

不要因为报告中写了“完成”或“上线”就直接采信。必须检查源码变更、before/after SHA、测试日志、Build/verify/preflight/deploy receipt、运行状态、控制台截图、MCP receipt、formal/Capture 数据不变证明和最终安全计数。
```

---

# 1. 权威范围与文件优先级

## 1.1 当前有效的执行包

当前 Codex 正在实施的权威执行包是：

```text
Study-Intake-Offline-MCP-PreLive-Finalization-Package-20260817-v2.zip
```

已核对的身份：

```text
ZIP SHA-256 = fc289a1bd5a678c5b90d88ae2c49e1f9ab4eac684f8677cfc2fa775076074cb0
内部 manifest identity = 2c50a046960da69eafceedff26f02e3d0c19a354e2ca0b84c55b910364408489
manifest 文件 SHA-256 = b206bc0fc66b894b2c25e0524250b21fb53ea6b8efa83bae58d9ff512eb119f6
```

核心文件：

1. `00_SOL_SINGLE_TURN_UNATTENDED_PROMPT.md`
2. `01_CORRECTED_SCOPE_AND_BOUNDARIES.md`
3. `02_IMPLEMENTATION_AND_DEPLOYMENT_PLAN.md`
4. `03_THREE_SUBJECT_SKILL_ALIGNMENT_SPEC.md`
5. `04_REAL_MCP_PREFLIGHT_DEBUG_RUNBOOK.md`
6. `05_VALIDATION_CONSOLE_FRONTEND_BACKEND_SPEC.md`
7. `06_FINAL_ACCEPTANCE_REPORT_TEMPLATE.md`
8. `07_AUDIT_PACKAGE_REQUIREMENTS.md`
9. `08_PENDING_LIVE_MODEL_CAPTURE_RUNBOOK.md`

## 1.2 已废止的方向

此前生成过一个允许真实 Terra、Luna、Capture、Promotion 和正式写入的 **Full Production** 执行包。该方向已经被用户明确否定并废止。

新项目审核时，不得把旧 Full Production 包中的授权视为仍然有效，也不得因为旧文件存在就认为本轮允许真实模型或真实 Capture。

## 1.3 需求优先级

发生冲突时，按以下顺序解释：

1. 本报告中的最终需求基线；
2. 上述 PreLive Finalization V2 执行包；
3. Codex 当前任务生成的实际计划、源码、测试和 receipt；
4. 上一轮离线实施报告，仅作为历史基线；
5. 更早的对话、旧计划和废止执行包。

---

# 2. 项目最终架构目标

正式生产架构最终应当是：

```text
学习线程中的当前 Sol
→ 数学 / 408 / 英语前台快速入口 Skill
→ 对应 Producer 生成 release-neutral Capture / receipt / attestation
→ Dispatcher + queue + Task Runner 自动消费
→ Terra Ultra 负责理解、规划、协调、整合和 fresh review
→ 多个 Luna Max 叶子分支通过各自独立的只读 MCP 会话读取
→ candidate + raw evidence + receipts + risk report
→ 生成 Sol 交接包
→ 另行启动的 Sol 对每项 adopt / modify / reject / request_reread / defer
→ 只有明确批准后才进入独立正式 writer transaction
```

但**当前这一轮 Codex 任务不是运行上述真实生产链**，而是把所有非 Live 工程做完并部署好，最终只剩以后额度恢复时的真实模型 Capture 验收。

---

# 3. 当前 Codex 任务的最高层目标

当前任务结束时，必须做到：

```text
deployment_ready = true
immutable_release_deployed = true
offline_acceptance_passed = true
three_subject_skill_alignment_complete = true
real_mcp_preflight_complete = true
validation_console_frontend_complete = true
validation_console_backend_complete = true
production_issuer_implemented = true
campaign_control_implemented = true
promotion_gate_implemented = true
live_model_execution = false
live_gate_locked = true
manual_authorization_present = false
capture_smoke_pending = true
production_accepted = false
formal_write_count = 0
```

一句话概括：

> **除真实 Terra/Luna + 真实 Capture Live 验收之外，其他源码、合同、控制台、MCP 公共底座、测试、Build、部署和交付全部完成。**

---

# 4. 执行模型、上下文与无人值守规则

Codex 必须满足：

1. 只使用当前同一个 **GPT-5.6 Sol 根会话**；
2. 在同一个 active turn / 同一个上下文中持续执行；
3. 利用 Sol 的约 100 万上下文，但完整日志应落盘，当前上下文只保留摘要、索引、SHA、关键决策和下一步；
4. 不创建 Terra、Luna 或任何其他工程 helper subagent；
5. 所有工程审核、修改、测试、修复、Build、部署和复验由根 Sol 串行完成；
6. 每阶段原子更新 `WORKLOG.md` 和 `RESUME.md`；
7. `RESUME.md` 必须写下一条精确命令，不能只写模糊状态；
8. 不得先只给计划并等待用户确认，完成审核和计划后应直接继续实施；
9. 用户睡觉期间，普通错误不得触发询问或等待。

正确的错误处理循环是：

```text
发现问题
→ 保存原始错误和证据
→ 定位根因
→ 修改真实 canonical authoring source
→ 新增/修正测试
→ 运行定向测试
→ 运行受影响回归
→ 重新尝试
→ Build / verify / transactional deploy
→ 从 deployed release 再验证
→ 直到 PASS 或真正 HARD_BLOCKER
```

`root_sol_helper_subagent_count` 必须始终为 0。

---

# 5. 本轮允许与禁止的动作

## 5.1 唯一允许的真实外部读取

只允许当前根 Sol 对三科 MCP 做受控只读预检：

```text
当前 Sol → 数学只读 MCP
当前 Sol → CS408 只读 MCP
当前 Sol → 英语只读 MCP
```

用途仅限：

- launcher、cwd、env、依赖和握手验证；
- `tools/list`、工具 allowlist 和 Schema 验证；
- 数据库/read root 身份和 subject scope 验证；
- 极少量只读查询；
- cursor/pagination 验证；
- timeout、shutdown、PID/PGID 回收验证；
- 发现错误后自动 Debug、修复和重试。

该路径必须标记为：

```text
purpose = infrastructure_preflight
capture_id = absent
production_task_id = absent
candidate_eligible = false
production_evidence = false
formal_write_allowed = false
write_call_count = 0
```

## 5.2 无条件禁止

当前任务无条件禁止：

1. 真实调用 `gpt-5.6-terra`；
2. 真实调用 `gpt-5.6-luna`；
3. 真实 Provider 模型请求；
4. 创建任何数学、408、英语真实 Capture；
5. 扫描、materialize、冻结、claim、消费或重放任何真实 Capture/backlog；
6. 运行真实单任务 runtime calibration；
7. 运行真实三科并发验收；
8. 运行真实单科多 Task 并发验收；
9. 运行真实 Monitor/Promotion 消费；
10. 对真实 Capture 签发可消费的 production authorization；
11. 设置或提升 `production_accepted=true`；
12. 调用晚间 Sol writer；
13. 写入错题卡、知识点、关系边、掌握状态或任何 formal surface；
14. 修改历史 Capture、历史 receipt、历史 immutable release；
15. 直接修改 `current` 指向的 immutable release；
16. 使用历史 Capture 冒充部署后 smoke；
17. 把 fake/fixture 证明写成真实模型证明。

## 5.3 最终安全计数

Codex 最终报告必须给出可核验来源，而不是口头声明：

```text
root_sol_helper_subagent_count = 0
real_terra_call_count = 0
real_luna_call_count = 0
real_provider_model_request_count = 0
live_capture_created_count = 0
live_capture_scanned_count = 0
live_capture_claimed_count = 0
live_capture_consumed_count = 0
real_monitor_consumption_count = 0
promotion_attempt_count = 0
production_accepted = false
formal_write_count = 0
sol_mcp_preflight_write_call_count = 0
```

允许非零的只有：

```text
sol_mcp_preflight_session_count >= 3
sol_mcp_preflight_read_call_count > 0
```

任何生产 Capture MCP 任务都必须为 0；报告必须把 Sol MCP preflight 与生产 Capture MCP 链分开计数。

---

# 6. 三科前台 Skill 对齐：独立硬验收门

这是当前任务最容易被遗漏、也最重要的要求之一。

不能只写“中央后台已修改”或“Producer 测试通过”，必须逐科证明真实学习线程使用的前台 Skill 与新后台合同完整闭合。

## 6.1 每科共同的完整闭包

```text
foreground Skill identity/version
+ authoritative Skill path/SHA
+ installed Skill path/SHA
+ authoritative/installed byte parity
+ Producer entrypoint
+ Producer source closure
+ Capture/event Schema
+ receipt Schema
+ producer-binding attestation Schema
+ subject fixture/contract vector
+ Scanner/Adapter
+ processing_binding_v3
+ background Processing Skill
+ Orchestrate Skill compatibility
+ subject MCP launcher/tool policy
+ output contracts
+ component-lock/release closure
```

任意一项缺失，该科都不能判为 PASS。

## 6.2 数学

必须对齐：

- Skill：`kaoyan-math-wrong-intake`；
- installed Skill：`~/.codex/skills/kaoyan-math-wrong-intake/SKILL.md`；
- authoritative/canonical Skill：必须在数学仓库中定位；若不存在，应建立明确 canonical source；
- Producer：数学系统中的 `quick_intake.py`；
- producer-binding attestation；
- Capture/receipt/Schema；
- Scanner/Adapter；
- math contract vector；
- background math processing Skill；
- math MCP launcher/tool policy；
- component lock 与 deployed release closure。

真实线程字段语义至少覆盖：

- 复盘模式；
- 新题模式；
- 题目图片和解析图；
- 用户原始作答；
- 对话中确认的错误点；
- 年份、做题日期；
- 缺失字段的显式状态。

## 6.3 计算机 408

必须对齐：

- Skill：`kaoyan-408-wrong-intake`；
- installed Skill：`~/.codex/skills/kaoyan-408-wrong-intake/SKILL.md`；
- authoritative/canonical Skill：学科仓库中的 `codex-skill-sources/...` 或真实等价路径；
- Producer：`intake_fact_capture_408.py`；
- producer-binding attestation；
- Capture/receipt/evidence/Schema；
- Scanner/Adapter；
- CS408 contract vector；
- background CS408 processing Skill；
- CS408 MCP launcher/tool policy；
- component lock 与 deployed release closure。

真实线程字段语义至少覆盖：

- 晨间复盘；
- 错题入库；
- 题目和代码；
- 用户错误链；
- 知识点和关联候选；
- 年份、日期；
- 图片和解析证据；
- 不绕过 evidence/receipt。

## 6.4 英语

必须对齐：

- Skill：`kaoyan-english-intensive-reading`；
- installed Skill：`~/.codex/skills/kaoyan-english-intensive-reading/SKILL.md`；
- authoritative/canonical Skill：必须在英语仓库中定位；若不存在，应建立明确 canonical source；
- Producer：英语 pipeline 的 `events.py` 及实际 CLI 调用入口；
- producer-binding attestation；
- event/receipt/Schema；
- Scanner/Adapter；
- English contract vector；
- background English processing Skill；
- English MCP launcher/tool policy；
- component lock 与 deployed release closure。

真实线程字段语义至少覆盖：

- 英文原文；
- 用户译文；
- 标准译文/答案；
- 词汇、句型、语法、表达错误；
- 已存在错题的状态更新候选；
- 日期和来源；
- event 与 receipt 闭包。

## 6.5 authoritative 与 installed 规则

- 已有 canonical source 时，所有修改必须先发生在 canonical source，再原子安装到 `~/.codex/skills`；
- 若数学或英语确实没有可证明的 canonical source，应先保存 installed preimage，再在对应学科仓库中建立明确 canonical 目录；
- 不得把长期漂移的 installed copy 静默认作权威源；
- 最终 authoritative 与 installed 必须 byte-identical；
- 对齐必须在实施前、修改后、Build 后和部署后各验证一次。

---

# 7. Shadow Capture：不触碰真实 Capture 的接口闭环

每科至少生成一个隔离 shadow Capture/fixture，用与真实聊天快速入库相同的字段形态验证：

```text
installed Skill 约束
→ Producer validation
→ event / receipt
→ release-neutral sidecar attestation
→ descriptor
→ Scanner / Adapter
→ processing_binding_v3
→ frozen task identity
→ pre-model tripwire
```

必须保证：

- synthetic ID；
- 临时目录或 fixture root；
- 不写真实 ledger；
- 不创建真实生产 sidecar 目录；
- 不扫描真实 backlog；
- 不走生产 Capture MCP 链；
- 不启动任何真实模型；
- 不计入 live Capture。

负面测试至少覆盖：

- Skill SHA drift；
- authoritative/installed mismatch；
- Producer closure drift；
- Capture/receipt Schema drift；
- sidecar 缺失或错误；
- subject mismatch；
- fixture vector drift；
- component lock mismatch；
- `formal_write_count != 0`；
- high-watermark 前历史 Capture 不回填；
- 所有失败均在模型、MCP 和正式写入前 fail closed。

---

# 8. 三科真实只读 MCP：必须 Debug 到通过

## 8.1 两层预检

### 协议层

```text
spawn exact deployed subject MCP launcher
→ initialize
→ tools/list
→ allowlist / Schema 比较
→ 极小只读调用
→ 可选一次 cursor continuation
→ graceful shutdown
→ PID/PGID cleanup verification
```

### 当前 Sol 工具层

若当前 Codex 客户端已经挂载对应 MCP，根 Sol可直接做极小查询；若未动态挂载，必须使用 exact protocol client 调用同一个 deployed launcher，不能因此停下。

无论哪种方式，都不得启动新的模型会话。

## 8.2 读取限制

每科默认：

- 至少一个 session；
- 一次 `tools/list`；
- 1～3 次只读调用；
- 每次 limit 1～5；
- 最多验证一次 cursor continuation；
- 原始返回落盘；
- Sol 上下文只保留字段摘要和 SHA；
- create/update/delete/upsert/write/commit/import/migrate/writer 一律拒绝且不得真实调用。

## 8.3 强制修复闭环

任何失败都必须：

```text
保存 stdout/stderr/protocol transcript
→ 记录失败调用和输入 SHA
→ 最小复现
→ 确定 launcher/env/依赖/Schema/路径/权限/cursor/cleanup 等根因
→ 修改 canonical authoring source
→ 新增或修正回归测试
→ 运行 targeted tests
→ 重跑该科 preflight
→ 运行共享回归
→ 三科 authoring preflight 稳定
→ Hermetic Build
→ immutable verify
→ transactional deploy
→ 从 deployed release 重跑三科 preflight
```

部署后仍失败，则继续修复、重建、重部署、重试。**只记录错误然后结束，不算完成。**

普通代码、配置、Schema、工具或路径错误不得写成 HARD_BLOCKER。

## 8.4 每科 PASS 条件

```text
initialize = passed
tools_list = passed
read_allowlist = passed
minimal_read = passed
result_schema = passed
subject_scope = passed
cursor_test = passed_or_not_applicable
write_call_count = 0
process_cleanup = passed
receipt_reopen = passed
```

三科还必须在 **deployed release** 上最终复验通过，而不能只在 authoring tree 通过。

---

# 9. 验收控制台：前端与后端都必须完成且用户可见

## 9.1 产品定位

- 这是上线前 commissioning、以后重新验收和紧急管理工具；
- 不是日常学习任务看板的替代品；
- 现有 `127.0.0.1:8767` Dashboard 应继续保持 GET-only；
- 优先新增独立 loopback 管理后端和页面；若复用同进程，必须证明路由、认证、CSRF 和权限严格隔离。

## 9.2 首页必须简单展示

顶部：

```text
Current release
Execution mode: OFFLINE
Live gate: LOCKED
Authorization: ABSENT
Production accepted: FALSE
Formal write: 0
```

三科前置状态：

```text
Math Skill 对齐：PASS/FAIL
CS408 Skill 对齐：PASS/FAIL
English Skill 对齐：PASS/FAIL

Math MCP 预检：PASS/FAIL
CS408 MCP 预检：PASS/FAIL
English MCP 预检：PASS/FAIL
```

## 9.3 三张主卡的准确语义

### Terra

- 显示：规划 / 协调 / 整合 / fresh review；
- 主按钮：`允许自动化处理`；
- 未来 Live 中负责放行 Terra；
- 当前本轮因 offline、无真实 Capture、无真实授权，生产按钮必须 disabled；
- fixture E2E 中验证状态机。

### Luna

- 显示：执行已验证 read plan 的只读分支；
- 展示计划、等待、运行、完成、失败 branch 数；
- 主按钮：`允许自动化读取`；
- 必须依赖 Terra read plan 已通过 Host 校验；
- 当前生产按钮必须 disabled；
- fixture E2E 中验证并发 campaign、relock 等状态。

### Sol 交接

- 显示：候选 / 证据 / 风险 / 串行复核提示词；
- 主按钮：`生成 Sol 交接包`；
- 点击只冻结和导出 handoff；
- **不能调用 Sol 模型**；
- **不能直接进行串行入库**；
- **不能正式写入**；
- 当前本轮只用 fixture 测试生成能力。

底部至少提供：

- `运行只读预检`；
- `查看技术验收报告`；
- `导出审核包`；
- `紧急锁定`；
- `查看未来 Live 验收步骤`。

复杂的 Capture SHA、release、activation、nonce、TTL、PID、MCP session 放在详情抽屉，不堆在首页。

## 9.4 后端必须具备

- console state projection；
- Skill alignment status；
- MCP preflight status；
- Terra/Luna/Sol-handoff 状态机；
- read-only preflight；
- production issuer receipt builder；
- exact Capture authorization builder；
- stage authorization；
- campaign registry；
- one-shot consumption；
- terminal relock；
- emergency lock；
- production promotion gate；
- technical report export；
- Sol handoff export；
- loopback、CSRF、nonce、replay rejection；
- atomic write、fsync、reopen verify；
- crash recovery。

本轮所有写动作只允许针对 fixture/temp state 测试；production authorization registry 必须为空，promotion apply 必须被拒绝。

---

# 10. Issuer、Campaign、Promotion：代码完成，但绝不真实执行

## 10.1 Production issuer

生产代码必须能精确绑定：

```text
subject
capture_id
capture_content_sha256
release_id
activation_id
allow_terra
allow_luna
maximum_tasks = 1
not_before
expires_at
nonce
issuer/user receipt
formal_write_allowed = false
```

但本轮不得对真实 Capture 实际签发，不得在 production state 留下 authorization。

## 10.2 Campaign fixture 验收

只使用 fake/fixture worker 验证：

- 单任务 campaign；
- 三科并发 campaign：每科一个独立 one-shot authorization；
- 单科多 Task campaign：每个 Task 独立 authorization；
- 一个任务失败不破坏其他 receipt；
- 不顺带消费 backlog；
- success/failure/cancel/timeout 后各自 relock；
- replay、expired、wrong-state 拒绝。

这些只是离线状态机和并发合同证明，不能写成真实 Terra/Luna 验收。

## 10.3 Promotion gate

必须实现独立、显式、可审计的 promotion gate，未来只有所有规定的 Live receipt 满足时才允许提升。

本轮：

```text
promotion_attempt_count = 0
production_accepted = false
```

只能 fixture 测试 preview/apply 合同，不能真实 apply。

---

# 11. 技术报告、MCP 报告和 Sol 交接包的关系

必须区分三类产物：

## 11.1 MCP 预检与 Debug 报告

记录：

- 当前 Sol 如何读取三科 MCP；
- 首次错误；
- 根因；
- 修改文件 before/after SHA；
- 测试；
- 重试次数；
- deployed-release 最终结果；
- 写调用为 0。

该报告用于证明 MCP 公共底座已经修到可读。

## 11.2 技术验收报告

记录：

- 三科 Skill 对齐；
- shadow Capture；
- 控制台前后端；
- issuer/campaign/promotion fixture；
- tests、Build、release、deploy；
- 数据不变和安全计数。

技术 receipt 应始终存在；正常时 UI 可显示摘要，异常时应能导出详细报告。

## 11.3 Sol 交接包

未来真实后台形成可信结果后：

- `accepted/corrected`：正常 handoff；
- `issues_found`：带风险 handoff，仍可交给 Sol 判断；
- `technical_quarantine`：只能生成 diagnostic package，不能生成可采用的正常 handoff；
- MCP 预检未通过或任务未运行：不生成业务 handoff。

当前本轮不运行真实 Capture，因此只验证 **fixture 下的交接包生成能力**；不会产生真正的业务 Sol 交接包，也不会调用 Sol。

---

# 12. 测试、Build、部署与部署后复验

## 12.1 测试必须覆盖

至少包括：

1. 三科 Skill/Producer/attestation/Scanner；
2. shadow Capture happy path 和 negative path；
3. MCP preflight Schema、allowlist、write rejection、timeout、cleanup、crash recovery；
4. 三科真实只读 MCP 外部集成证据；
5. 控制台 API、CSRF、nonce、replay、atomicity；
6. 前端三卡状态机、错误态、刷新恢复、报告导出；
7. issuer、one-shot、campaign、terminal relock；
8. promotion gate；
9. fake branch concurrency、分波、fairness、cleanup；
10. offline tripwire；
11. Dashboard 回归；
12. 三科 Producer 全量回归；
13. 完整 Core discovery；
14. release manager；
15. formal/Capture 不变。

每个 suite 必须报告完整命令、test 数、耗时、exit code、日志路径和日志 SHA。

## 12.2 Build

必须：

- 冻结新 fixture；
- 更新 component registry/lock；
- 将三科 Skill/Producer/Schema/vector、MCP preflight、控制台、issuer/campaign/promotion 资产纳入 release closure；
- 执行 final release gate；
- Build 新 immutable release；
- verify source/generated/mode/owner/xattr/manifest/component lock/config/model role/tool policy；
- 保留 rollback release；
- 不删除或修改历史 immutable evidence。

## 12.3 事务部署

必须：

- read-only preflight；
- precise drain receipt；
- prepare/activation/postcommit receipt；
- transactional deploy；
- 失败时 rollback、修复、重建、重试；
- 部署后继续保持 offline、locked、authorization absent、production accepted false。

## 12.4 部署后必须从 deployed release 复验

不能只在 authoring tree 中通过。必须重新验证：

1. 三科 authoritative/installed Skill byte parity；
2. component lock 与 Producer closure；
3. 三科 shadow Capture；
4. 三科真实只读 MCP preflight；
5. 控制台前后端 fixture E2E；
6. issuer/campaign/promotion fixture；
7. formal surface 和 Capture history 前后完全一致；
8. 零 Live 计数；
9. Dispatcher 无子进程；
10. production authorization registry empty；
11. LaunchAgent、PID/PGID、WorkingDirectory、端口 owner、healthz、projection 正常。

---

# 13. Codex 必须交付的文件与证据

至少应交付：

- `BASELINE_AUDIT.md`
- `IMPLEMENTATION_PLAN.md`
- `THREE_SUBJECT_SKILL_ALIGNMENT_REPORT.md`
- `MCP_PREFLIGHT_DEBUG_REPORT.md`
- `VALIDATION_CONSOLE_ACCEPTANCE_REPORT.md`
- `FINAL_PRELIVE_ACCEPTANCE_REPORT.md`
- `PENDING_MANUAL_LIVE_VALIDATION.md`
- `WORKLOG.md`
- `RESUME.md`
- `CHANGE_SHA256_MANIFEST.json`
- `AUDIT_PACKAGE_MANIFEST.json`
- 前端首页、Terra、Luna、Sol 交接、offline/error 状态截图与 SHA
- 三科 MCP session/call/terminal receipts
- targeted/full tests 的完整日志和 SHA
- fixture identity
- release manifest、config、component lock
- Build/verify/preflight/deploy/rollback receipts
- formal surface 与 Capture history 前后不变证明
- 只读审核 ZIP、ZIP SHA、manifest 和可重开验证结果

最终报告不得只是一段聊天总结，也不得只有测试数量，没有日志路径、SHA 和 receipt。

---

# 14. Codex 最终报告必须回答的十项 YES/NO

```text
PRELIVE_ENGINEERING_COMPLETE = YES | NO
THREE_SUBJECT_SKILL_ALIGNMENT_COMPLETE = YES | NO
REAL_MCP_PREFLIGHT_COMPLETE = YES | NO
VALIDATION_CONSOLE_FRONTEND_COMPLETE = YES | NO
VALIDATION_CONSOLE_BACKEND_COMPLETE = YES | NO
PRODUCTION_ISSUER_IMPLEMENTED = YES | NO
CAMPAIGN_CONTROL_IMPLEMENTED = YES | NO
PROMOTION_GATE_IMPLEMENTED = YES | NO
IMMUTABLE_RELEASE_DEPLOYED = YES | NO
ONLY_REAL_MODEL_CAPTURE_VALIDATION_REMAINS = YES | NO
```

最后一项只有在其他非 Live 项全部有源码、测试、SHA、receipt、部署运行态和安全计数支撑时，才能写 YES。

---

# 15. 新项目审核 Codex 报告的对照矩阵

新项目收到 Codex 最终报告后，应逐项填写：

| 审核项 | 需求 | 必须看到的证据 | 判定 |
|---|---|---|---|
| 执行会话 | 同一个 GPT-5.6 Sol、同一 active turn | 会话/时间线/WORKLOG | PASS / PARTIAL / FAIL / 证据不足 |
| helper subagent | 始终为 0 | tripwire、计数、进程/事件记录 |  |
| 真实 Terra/Luna | 均为 0 | 安全计数、进程和 Provider 证据 |  |
| 真实 Capture | 创建/扫描/claim/消费均为 0 | Capture manifest、sidecar、dispatcher 计数 |  |
| Monitor/Promotion | 真实消费/尝试均为 0 | registry、receipt、计数 |  |
| Formal 写入 | 始终为 0 | formal manifest before/after |  |
| 数学 Skill | 全链闭合、canonical/installed 同字节 | 路径、SHA、调用链、shadow/negative tests |  |
| 408 Skill | 全链闭合、canonical/installed 同字节 | 同上 |  |
| 英语 Skill | 全链闭合、canonical/installed 同字节 | 同上 |  |
| 真实 MCP Math | Debug 到 deployed PASS | 首次结果、修复、重试、receipt |  |
| 真实 MCP CS408 | Debug 到 deployed PASS | 同上 |  |
| 真实 MCP English | Debug 到 deployed PASS | 同上 |  |
| MCP 写入 | 0 | allowlist、write rejection、计数 |  |
| Shadow Capture | 三科临时闭环，不写真实 ledger | fixture ID/SHA、路径、pre-model stop |  |
| 控制台前端 | 用户可见、三卡简单界面 | 页面、截图、前端测试 |  |
| 控制台后端 | 安全控制面完整 | API、CSRF/nonce、replay、atomicity、crash tests |  |
| Terra 卡 | 当前生产 disabled，fixture 状态机通过 | UI/API/E2E |  |
| Luna 卡 | 依赖 verified plan，当前 disabled | UI/API/E2E |  |
| Sol 卡 | 只导出 handoff，不调用 Sol/不写入 | 代码、测试、零模型/写入计数 |  |
| Issuer | 生产代码完整，真实 registry 空 | Schema、fixture、state proof |  |
| Campaign | 单任务/三科并发/单科多 Task fixture | 每 Capture 独立授权、failure isolation |  |
| Promotion gate | 已实现但未 apply | fixture tests、production false |  |
| Build | 新 immutable release 已构建和 verify | release ID、manifest/lock/config SHA |  |
| 部署 | 事务部署完成 | drain/prepare/activation/postcommit |  |
| 运行态 | offline/locked/authorization absent | LaunchAgent、PID/PGID、端口、healthz |  |
| 数据不变 | formal/Capture 完全不变 | root-by-root manifest/diff |  |
| 审核包 | 完整、只读、可重开 | ZIP SHA、manifest、文件数、reopen |  |
| 最终范围 | 只剩未来真实模型 Capture 验收 | 未完成项清单和上述全部证据 |  |

---

# 16. 高风险红旗

看到以下任一情况，不能直接判为完成：

1. 报告只写“全部完成”，没有 before/after SHA、日志或 receipt；
2. 实际调用了 Terra、Luna 或 Provider；
3. 创建、扫描、claim 或消费了真实 Capture；
4. 对 production state 实际签发 authorization；
5. 执行了 Monitor/Promotion 或把 `production_accepted` 改成 true；
6. 发生 formal write；
7. MCP 报错只被记录，没有修复、重试和 deployed 复验；
8. 只验证中央后台，没有逐科验证 installed Skill；
9. 数学或英语缺少 canonical source，却直接把 installed copy 当长期权威；
10. 三科 Skill 只有测试通过，没有真实路径、SHA 和 byte parity；
11. shadow Capture 写入了真实 ledger 或创建了真实 sidecar；
12. 控制台只有设计稿、文档或 mock，没有实际前后端和截图；
13. Sol 按钮实际启动了 Sol 模型或直接正式入库；
14. 为了控制台写功能破坏了现有 8767 GET-only Dashboard；
15. issuer/campaign/promotion 只有 Schema，没有接入真实生产代码路径；
16. fixture 并发被写成真实 Terra/Luna 并发；
17. 只在 authoring tree 通过，部署后的 Skill/MCP 没复验；
18. production authorization registry 非空；
19. current 被原地修改，或历史 immutable release/receipt 被改写；
20. 最终仍有非 Live 工程待办，却写 `ONLY_REAL_MODEL_CAPTURE_VALIDATION_REMAINS=YES`。

---

# 17. 当前任务完成后，未来仍需执行的真实 Live 阶段

当前 Codex 任务不得执行以下步骤。只有额度恢复并由用户重新明确授权后，才进入：

1. 创建部署后的全新真实 Capture；
2. 单任务真实 Terra/Luna runtime calibration；
3. 三科并发 Live 验收；
4. 单科多 Task Live 验收；
5. 验证真实 parent/child event、Luna branch identity、每 branch 独立 MCP launcher/session 和真实并发；
6. 验证 terminal authorization consumption/relock；
7. 独立、显式、可审计的 production promotion；
8. 另行授权的 Sol 串行复核；
9. 另行授权的正式 writer transaction。

注意：当前控制台和 issuer/campaign/promotion 只是把这些未来步骤的工程能力提前做好并锁住，不代表真实验收已经通过。

---

# 18. 新项目最终应给用户的审核结论格式

```text
一、总体结论
- 非 Live 工程：通过 / 部分通过 / 不通过
- 三科 Skill 对齐：通过 / 部分通过 / 不通过
- 三科 MCP 预检：通过 / 部分通过 / 不通过
- 验收控制台前端：通过 / 部分通过 / 不通过
- 验收控制台后端：通过 / 部分通过 / 不通过
- Issuer/Campaign/Promotion gate：通过 / 部分通过 / 不通过
- immutable release 与部署：通过 / 部分通过 / 不通过
- 安全边界：通过 / 有违规
- 是否只剩真实模型 Capture 验收：是 / 否

二、证据充分的已完成项
- ...

三、部分完成或证据不足项
- ...

四、明确未完成项
- ...

五、违规或高风险项
- ...

六、报告中的矛盾
- ...

七、三科逐科审核
- 数学：...
- 408：...
- 英语：...

八、最小修复清单
1. ...

九、仍待未来 Live 验证
- ...

十、建议下一步
- 在完成审核前，不运行真实 Capture、Terra、Luna、Promotion 或正式写入。
```

---

# 19. 已知的上轮起始基线，仅供辨认

在当前 PreLive Finalization 任务开始之前，上一轮报告称系统已达到离线生产就绪，canonical release 为：

```text
ad1807186ac277c6bacfb7fd8d83b9cbc86cf75027698e70f994f3228d815cc9
```

当时状态为：

```text
execution_mode = offline
live_gate_locked = true
manual_authorization_present = false
capture_smoke_pending = true
production_accepted = false
formal_write_count = 0
```

当前 Codex 任务可能会构建并部署新的 release。因此新项目收到最终报告后必须重新读取 `current`、release ID、manifest、component lock、receipt 和运行态，不能继续把上面的 release 当作最终事实。

---

# 20. 最重要的五句话

1. **本轮唯一允许的真实外部执行，是当前 Sol 对数学、408、英语 MCP 的受控只读预检。**
2. **MCP 预检失败必须修复、测试、重建、部署并重试，不能只记录错误。**
3. **数学、408、英语三个真实前台 Skill 都必须逐科对齐，且 authoritative 与 installed 最终 byte-identical。**
4. **控制台前后端、issuer、campaign、promotion gate 都要完成，但真实 Terra、Luna、Capture、Promotion 和正式写入必须全部为 0。**
5. **只有所有非 Live 项都有源码、测试、SHA、receipt 和部署证据后，才能说“现在只剩真实模型 Capture 验收”。**
